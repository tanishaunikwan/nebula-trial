import { useEffect, useRef, useState } from 'react';
import Lenis from '@studio-freight/lenis';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const MAIN_FRAME_COUNT = 192;
const MAIN_IMAGES_DIR = '/images/video main/ezgif-frame-';

const ALLURE_FRAME_COUNT = 165;
const ALLURE_IMAGES_DIR = '/images/video/ezgif-frame-';

const BESTSELLERS = [
  { id: 1, name: 'Abhiyant', price: '₹1,45,000', img: '/images/bestseller/abhiyant_Updated_D.webp' },
  { id: 2, name: 'Art Deco', price: '₹1,95,000', img: '/images/bestseller/artdeco_Updated_D.jpg' },
  { id: 3, name: 'Ashvi', price: '₹1,10,000', img: '/images/bestseller/ashvi_Updated_D.webp' },
  { id: 4, name: 'Lustre', price: '₹1,75,000', img: '/images/bestseller/lustre_Updated_D.webp' },
  { id: 5, name: 'Samrat', price: '₹2,50,000', img: '/images/bestseller/samrat_Updated_D.jpg' },
  { id: 6, name: 'Varsha', price: '₹1,35,000', img: '/images/bestseller/varsha_Updated_D.webp' },
];

const FAQS = [
  { q: 'What defines the essence of Nebula?', a: 'Crafted entirely in solid 18k gold, Nebula represents the pinnacle of Indian artisanship blended with modern cinematic horology. It is a wearable legacy.' },
  { q: 'Is there a warranty provided?', a: 'Every timepiece is accompanied by a comprehensive 2-year international warranty, honoring the mastery of its creation.' },
  { q: 'How should I care for 18k solid gold?', a: 'Maintain its eternal luster by wiping gently with a lint-free cloth. Shield it from extreme elements to preserve its sculptural integrity.' },
];

function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const horizontalRef = useRef<HTMLDivElement>(null);
  const manifestoImgRef = useRef<HTMLImageElement>(null);
  
  const [imagesLoaded, setImagesLoaded] = useState(0);
  const imagesMainRef = useRef<HTMLImageElement[]>([]);
  const imagesAllureRef = useRef<HTMLImageElement[]>([]);
  const [activeFaq, setActiveFaq] = useState<number | null>(null);

  // Preload images
  useEffect(() => {
    let loadedCount = 0;
    const totalFrames = MAIN_FRAME_COUNT + ALLURE_FRAME_COUNT;

    const mainImages: HTMLImageElement[] = [];
    const allureImages: HTMLImageElement[] = [];

    const handleLoad = () => {
      loadedCount++;
      setImagesLoaded(loadedCount);
      if (loadedCount === totalFrames && canvasRef.current) {
        const ctx = canvasRef.current.getContext('2d');
        if (ctx && mainImages[0]) drawFrame(mainImages[0], canvasRef.current, ctx);
      }
    };

    for (let i = 1; i <= MAIN_FRAME_COUNT; i++) {
      const img = new Image();
      const frameNum = i.toString().padStart(3, '0');
      img.src = `${MAIN_IMAGES_DIR}${frameNum}.jpg`;
      img.onload = handleLoad;
      mainImages.push(img);
    }
    
    for (let i = 1; i <= ALLURE_FRAME_COUNT; i++) {
      const img = new Image();
      const frameNum = i.toString().padStart(3, '0');
      img.src = `${ALLURE_IMAGES_DIR}${frameNum}.jpg`;
      img.onload = handleLoad;
      allureImages.push(img);
    }

    imagesMainRef.current = mainImages;
    imagesAllureRef.current = allureImages;
  }, []);

  // Lenis & GSAP Setup
  useEffect(() => {
    const lenis = new Lenis({
      duration: 1.5,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      wheelMultiplier: 1,
      touchMultiplier: 2,
    });

    function raf(time: number) {
      lenis.raf(time);
      requestAnimationFrame(raf);
    }
    requestAnimationFrame(raf);
    lenis.on('scroll', ScrollTrigger.update);

    gsap.ticker.add((time) => lenis.raf(time * 1000));
    gsap.ticker.lagSmoothing(0);

    return () => {
      lenis.destroy();
      gsap.ticker.remove(lenis.raf);
    };
  }, []);

  const drawFrame = (img: HTMLImageElement, canvas: HTMLCanvasElement, ctx: CanvasRenderingContext2D) => {
    const canvasRatio = canvas.width / canvas.height;
    const imgRatio = img.width / img.height;
    let renderWidth, renderHeight, x, y;

    if (canvasRatio > imgRatio) {
      renderWidth = canvas.width;
      renderHeight = canvas.width / imgRatio;
      x = 0; y = (canvas.height - renderHeight) / 2;
    } else {
      renderWidth = canvas.height * imgRatio;
      renderHeight = canvas.height;
      x = (canvas.width - renderWidth) / 2; y = 0;
    }
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(img, x, y, renderWidth, renderHeight);
  };

  // Complex GSAP Choreography
  useEffect(() => {
    const totalFrames = MAIN_FRAME_COUNT + ALLURE_FRAME_COUNT;
    if (imagesLoaded < totalFrames || !canvasRef.current || !containerRef.current) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      drawFrame(imagesMainRef.current[0], canvas, ctx);
    };
    window.addEventListener('resize', handleResize);
    handleResize();

    // 1. Canvas Scrub (Intro - Video Main)
    ScrollTrigger.create({
      trigger: '.canvas-scroll-area',
      start: 'top top',
      end: 'bottom bottom',
      scrub: 1,
      onUpdate: (self) => {
        const frameIndex = Math.floor(self.progress * (MAIN_FRAME_COUNT - 1));
        if (imagesMainRef.current[frameIndex]) {
          requestAnimationFrame(() => drawFrame(imagesMainRef.current[frameIndex], canvas, ctx));
        }
      }
    });

    // 1b. Hero Text Choreography
    const tlHero = gsap.timeline({
      scrollTrigger: {
        trigger: '.canvas-scroll-area',
        start: 'top top',
        end: 'bottom bottom',
        scrub: true,
      }
    });

    tlHero
      .fromTo('.hero-phrase-1', { opacity: 0, y: 50 }, { opacity: 1, y: 0, duration: 1 })
      .to('.hero-phrase-1', { opacity: 0, y: -50, duration: 1 })
      .fromTo('.hero-phrase-2', { opacity: 0, y: 50 }, { opacity: 1, y: 0, duration: 1 })
      .to('.hero-phrase-2', { opacity: 0, y: -50, duration: 1 })
      .fromTo('.hero-cta-wrapper', { opacity: 0, y: 20 }, { opacity: 1, y: 0, duration: 0.5 });


    // 2. Manifesto Section Pinning and Frame Scrubbing (Allure of Time)
    const manifestoImg = manifestoImgRef.current;
    if (manifestoImg) {
      ScrollTrigger.create({
        trigger: '.manifesto-section',
        start: 'top top',
        end: 'bottom bottom',
        scrub: 1,
        onUpdate: (self) => {
          const frameIndex = Math.floor(self.progress * (ALLURE_FRAME_COUNT - 1));
          if (imagesAllureRef.current[frameIndex]) {
            manifestoImg.src = imagesAllureRef.current[frameIndex].src;
          }
        }
      });
    }

    // 3. Horizontal Scroll (Bestsellers)
    if (horizontalRef.current) {
      const horizontalContainer = horizontalRef.current;
      const scrollAmount = horizontalContainer.scrollWidth - window.innerWidth;
      
      gsap.to(horizontalContainer, {
        x: -scrollAmount,
        ease: "none",
        scrollTrigger: {
          trigger: '.horizontal-scroll-section',
          start: 'top top',
          end: () => `+=${scrollAmount}`,
          pin: true,
          scrub: 1,
          invalidateOnRefresh: true
        }
      });
    }

    // Generic Fade Reveals
    gsap.utils.toArray('.gsap-reveal').forEach((el: any) => {
      gsap.fromTo(el, { y: 100, opacity: 0 }, {
        y: 0, opacity: 1, duration: 1.5, ease: 'power4.out',
        scrollTrigger: { trigger: el, start: 'top 85%' }
      });
    });

    return () => {
      window.removeEventListener('resize', handleResize);
      ScrollTrigger.getAll().forEach(t => t.kill());
    };
  }, [imagesLoaded]);

  const toggleFaq = (index: number) => setActiveFaq(activeFaq === index ? null : index);

  const totalFrames = MAIN_FRAME_COUNT + ALLURE_FRAME_COUNT;

  return (
    <div ref={containerRef} style={{ position: 'relative' }}>
      
      {imagesLoaded < totalFrames && (
        <div className="fixed inset-0 z-50 flex-center solid-bg serif" style={{ color: 'var(--color-text)', position: 'fixed', inset: 0, zIndex: 9999, fontSize: '2rem' }}>
          Crafting Experience... {Math.round((imagesLoaded / totalFrames) * 100)}%
        </div>
      )}

      {/* Canvas Layer (Hero sequence) */}
      <div className="canvas-container">
        <canvas ref={canvasRef} />
      </div>

      <div className="content-layer">
        
        {/* Intro Scrub Area */}
        <div className="canvas-scroll-area hero-scroll-wrapper">
          <div className="hero-text-container container">
            <h2 className="hero-phrase hero-phrase-1 serif mega-title text-gold" style={{ textShadow: '0 4px 20px rgba(0,0,0,0.15)' }}>NEBULA<br/>BY TITAN</h2>
            <h1 className="hero-phrase hero-phrase-2 serif large-title text-gold" style={{ textShadow: '0 4px 20px rgba(0,0,0,0.15)' }}>18K SOLID<br/>GOLD</h1>
            <div className="hero-cta-wrapper">
              <a href="#collection" className="editorial-cta">Discover the Collection</a>
            </div>
          </div>
        </div>

        {/* Manifesto Section (Pinning & Frame Scrubbing) */}
        <section className="solid-bg manifesto-section">
          <div className="manifesto-sticky-wrapper container">
            <div className="manifesto-left">
              <h2 className="large-title serif text-gold">THE<br/>ALLURE<br/>OF<br/>TIME</h2>
              <p className="body-text" style={{ marginTop: '3rem', maxWidth: '400px' }}>
                Inspired by the divine proportions of Indian architecture, Nebula transcends timekeeping. It is a masterpiece forged in eternal gold, capturing the essence of a legacy that refuses to fade.
              </p>
            </div>
            <div className="manifesto-right">
              <div className="manifesto-image-block temple-arch">
                {/* Initial image, gets overwritten by GSAP scroll scrubbing with the allure sequence */}
                <img ref={manifestoImgRef} src={`${ALLURE_IMAGES_DIR}001.jpg`} alt="Craftsmanship Sequence" />
              </div>
            </div>
          </div>
        </section>

        <div className="ornament-divider"></div>

        {/* Horizontal Scroll (Bestsellers) */}
        <section id="collection" className="horizontal-scroll-section solid-bg">
          <div className="container" style={{ position: 'absolute', top: '15vh', left: 0 }}>
             <h2 className="medium-title serif text-gold">THE ICONS</h2>
             <p className="body-text">Masterpieces of Indian Craftsmanship</p>
          </div>
          <div className="horizontal-scroll-container" ref={horizontalRef}>
            <div style={{ flex: '0 0 30vw' }} /> {/* Spacer */}
            {BESTSELLERS.map((item) => (
              <div key={item.id} className="horizontal-item">
                <div className="horizontal-item-image temple-arch">
                   <img src={item.img} alt={item.name} />
                </div>
                <h3 className="horizontal-item-title serif">{item.name}</h3>
                <p className="horizontal-item-price">{item.price}</p>
              </div>
            ))}
            <div style={{ flex: '0 0 30vw' }} /> {/* Spacer */}
          </div>
        </section>

        <div className="ornament-divider"></div>

        {/* Editorial Grids (Him/Her) - One Fold Vertically */}
        <section className="solid-bg container" style={{ height: '100vh', display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: '0 6vw' }}>
          
          <div className="editorial-grid gsap-reveal" style={{ alignItems: 'center', margin: '2vh auto', maxWidth: '1000px', width: '100%', gap: '8vw' }}>
            <div className="grid-text-col" style={{ alignItems: 'flex-end', textAlign: 'right' }}>
              <h2 className="large-title serif text-gold" style={{ fontSize: 'clamp(2rem, 4vw, 4rem)' }}>FOR HIM</h2>
              <p className="body-text" style={{ marginTop: '0.5rem', maxWidth: '300px' }}>
                Bold architecture, intricate filigree, and unyielding strength.
              </p>
              <a href="#" className="editorial-cta" style={{ width: 'fit-content', marginTop: '1rem' }}>Explore Men's</a>
            </div>
            <div className="grid-img-col temple-arch" style={{ height: '38vh', width: 'auto', aspectRatio: '3/4', justifySelf: 'flex-start' }}>
               <img src="/images/gender/for him.jpg" alt="Nebula For Him" />
            </div>
          </div>

          <div className="editorial-grid reversed gsap-reveal" style={{ alignItems: 'center', margin: '2vh auto', maxWidth: '1000px', width: '100%', gap: '8vw' }}>
            <div className="grid-img-col temple-arch" style={{ height: '38vh', width: 'auto', aspectRatio: '3/4', justifySelf: 'flex-end' }}>
               <img src="/images/gender/for her.jpg" alt="Nebula For Her" />
            </div>
            <div className="grid-text-col" style={{ alignItems: 'flex-start', textAlign: 'left' }}>
              <h2 className="large-title serif text-gold" style={{ fontSize: 'clamp(2rem, 4vw, 4rem)' }}>FOR HER</h2>
              <p className="body-text" style={{ marginTop: '0.5rem', maxWidth: '300px' }}>
                Delicate symmetry, timeless elegance, and exquisite artistry.
              </p>
              <a href="#" className="editorial-cta" style={{ width: 'fit-content', marginTop: '1rem' }}>Explore Women's</a>
            </div>
          </div>

        </section>

        <div className="ornament-divider"></div>

        {/* Form */}
        <section className="solid-bg container" style={{ paddingBottom: '10vh' }}>
          <div className="minimal-form gsap-reveal temple-arch">
            <h2 className="medium-title serif text-gold" style={{ marginBottom: '5rem', textAlign: 'center' }}>BECOME PART<br/>OF THE LEGACY</h2>
            <form onSubmit={(e) => e.preventDefault()}>
              <div className="minimal-input-group">
                <input type="text" id="name" className="minimal-input" placeholder=" " required />
                <label htmlFor="name" className="minimal-label">Full Name</label>
              </div>
              <div className="minimal-input-group">
                <input type="email" id="email" className="minimal-input" placeholder=" " required />
                <label htmlFor="email" className="minimal-label">Email Address</label>
              </div>
              <div className="minimal-input-group">
                <input type="tel" id="contact" className="minimal-input" placeholder=" " required />
                <label htmlFor="contact" className="minimal-label">Contact Number</label>
              </div>
              <div className="flex-center">
                <button type="submit" className="minimal-submit">
                  <span>SUBMIT</span>
                  <span style={{ fontSize: '1.5rem', color: 'var(--color-gold)' }}>&rarr;</span>
                </button>
              </div>
            </form>
          </div>
        </section>

        {/* FAQ */}
        <section className="solid-bg container" style={{ paddingBottom: '20vh' }}>
          <div className="minimal-faq gsap-reveal">
            <h2 className="medium-title serif text-gold" style={{ marginBottom: '4rem', textAlign: 'center' }}>FAQS</h2>
            {FAQS.map((faq, index) => (
              <div key={index} className={`faq-row ${activeFaq === index ? 'active' : ''}`}>
                <div className="faq-q" onClick={() => toggleFaq(index)}>
                  {faq.q}
                  <div className="faq-cross" />
                </div>
                <div className="faq-a" style={{ maxHeight: activeFaq === index ? '300px' : '0px' }}>
                  <p>{faq.a}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Footer */}
        <footer className="solid-bg container" style={{ padding: '5vh 6vw', borderTop: '1px solid rgba(197, 160, 89, 0.2)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <p className="serif text-gold" style={{ letterSpacing: '0.2em' }}>NEBULA BY TITAN</p>
          <p className="body-text" style={{ fontSize: '0.8rem' }}>© 2026 TITAN. ALL RIGHTS RESERVED.</p>
        </footer>

      </div>
    </div>
  );
}

export default App;
